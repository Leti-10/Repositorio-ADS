package DAO;

import factory.Conexao;
import modelo.Aluno;
import modelo.Curso;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO {
    public boolean cpfExiste(String cpf) {
        String sql = "select * from aluno where cpf = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void inserirAluno(Aluno aluno) {
        String sql = "insert into aluno(nome, cpf, email, data_nascimento, ativo, id_curso) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setString(3, aluno.getEmail());
            stmt.setDate(4, Date.valueOf(aluno.getData_Nascimento()));
            stmt.setInt(5, aluno.getAtivo());
            stmt.setInt(6, aluno.getCurso().getIdCurso());

            stmt.executeUpdate();
            System.out.println("Aluno adicionado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Aluno> listarAlunos() {
        List<Aluno> alunos = new ArrayList<>();
        String sql = "SELECT "
                + "a.idAluno, a.nome, a.cpf, a.email, a.data_nascimento, a.ativo AS aluno_ativo, "
                + "c.idCurso, c.nome AS curso_nome, c.carga_horaria, c.limite_alunos, c.ativo AS curso_ativo "
                + "FROM aluno a "
                + "LEFT JOIN curso c ON a.id_Curso = c.idCurso "
                + "WHERE a.ativo = 1";

        try (Connection conn = Conexao.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Curso curso = null;
                int idCurso = rs.getInt("idCurso");
                if (!rs.wasNull()) {
                    curso = new Curso(
                            rs.getString("curso_nome"),
                            rs.getInt("carga_horaria"),
                            rs.getInt("limite_alunos"),
                            rs.getInt("curso_ativo"),
                            new ArrayList<>()
                    );
                    curso.setIdCurso(idCurso);
                }

                Aluno aluno = new Aluno(
                        rs.getString("nome"),
                        rs.getString("cpf"),
                        0, // Telefone não está no SELECT
                        rs.getString("email"),
                        rs.getDate("data_nascimento").toLocalDate(),
                        rs.getInt("aluno_ativo"),
                        curso
                );

                aluno.setIdAluno(rs.getInt("idAluno"));
                aluno.setAtivo(rs.getInt("aluno_ativo"));
                alunos.add(aluno);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alunos;
    }

    public List<Aluno> buscarAlunos(String campo, String valor) {
        List<Aluno> alunos = new ArrayList<>();

        String coluna;
        switch (campo) {
            case "Nome":
                coluna = "a.nome";
                break;
            case "CPF":
                coluna = "a.cpf";
                break;
            case "Curso":
                coluna = "c.nome";
                break;
            default:
                throw new IllegalArgumentException("Filtro inválido!");
        }

        String sql = "SELECT a.idAluno, a.nome AS aluno_nome, a.cpf, a.email, a.data_nascimento, a.ativo AS aluno_ativo, "
                + "c.idCurso, c.nome AS curso_nome, c.carga_horaria, c.limite_alunos, c.ativo AS curso_ativo "
                + "FROM aluno a "
                + "LEFT JOIN curso c ON a.id_Curso = c.idCurso "
                + "WHERE " + coluna + " LIKE ? AND a.ativo = 1";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, "%" + valor + "%");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Curso curso = new Curso(
                        rs.getString("curso_nome"),
                        rs.getInt("carga_horaria"),
                        rs.getInt("limite_alunos"),
                        rs.getInt("curso_ativo"),
                        new ArrayList<>()
                );
                curso.setIdCurso(rs.getInt("idCurso"));

                Aluno aluno = new Aluno(
                        rs.getString("aluno_nome"),
                        rs.getString("cpf"),
                        0, // Telefone não está no SELECT
                        rs.getString("email"),
                        rs.getDate("data_nascimento").toLocalDate(),
                        rs.getInt("aluno_ativo"),
                        curso
                );
                aluno.setIdAluno(rs.getInt("idAluno"));
                aluno.setAtivo(rs.getInt("aluno_ativo"));
                alunos.add(aluno);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return alunos;
    }


    public void alterarAluno(Aluno aluno) {
        String sql = "UPDATE aluno SET nome = ?, cpf = ?, email = ?, data_nascimento = ?, ativo = ?, id_curso = ? WHERE idAluno = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setString(3, aluno.getEmail());
            stmt.setDate(4, Date.valueOf(aluno.getData_Nascimento()));
            stmt.setInt(5, aluno.getAtivo());
            stmt.setInt(6, aluno.getCurso().getIdCurso());
            stmt.setInt(7, aluno.getIdAluno());

            int linhasAfetadas = stmt.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Aluno atualizado com sucesso!");
            } else {
                System.out.println("Nenhum aluno foi atualizado. Verifique o ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirAluno(int idAluno) {
        String sql = "DELETE FROM aluno WHERE idAluno = ?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idAluno);
            int linhasAfetadas = stmt.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Aluno excluído com sucesso!");
            } else {
                System.out.println("Nenhum aluno foi excluído. Verifique o ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}